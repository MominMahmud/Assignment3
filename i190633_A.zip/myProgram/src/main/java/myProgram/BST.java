package myProgram;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.io.File;
import java.io.IOException;



public class BST extends Thread {
	protected BSTNode root = null;
	 String stringFunc ;
	
     protected BST X=null;
    
     public BST(String Y)
    
     {
    
        stringFunc=Y+".txt" ;
    
    }
    
    public BST()
    
    {
    
        cout<<" ";
    
    }
    

    
    public void run(){
	
        Scanner sc = new Scanner(System.in) ;
	
        try {
	
            String token = "" ;
	
            sc = new Scanner(new File(stringFunc));
	
    
            while(sc.hasNext()){
	
                token = sc.next();
	
                X.insert(token);
	
            }
	
        } catch (IOException e1) {
	
            
			
            e1.printStackTrace();
		}

	    

	}

    

    
    public boolean isEmpty() 
    
    {
    
        return root == null;
    
    }
    

    
    public void insert(String data) 
    
    {
    
        boolean g= false;
	
        BSTNode p = root, prev = null;
	
        while (p != null) {
	
            prev = p;
	
            if (p.data.compareTo(data) < 0)
	
            p = p.right;
	
            else if(p.data==data) {
	
                g=true;
	
                break;
	
            }
	
            else 
	
            p = p.left;
	
        }
	
        if(g==true)
	
        {
	
            return;
	
        }
	
        if (root == null)
	
        root = new BSTNode(data);
	
        else if (prev.data.compareTo(data) < 0)
	
        prev.right = new BSTNode(data);
	
        else prev.left  = new BSTNode(data);
    
    }   


    
    public boolean breadthFirst(String cmp)
    
    {
        BSTNode p = root;
    
        Queue<BSTNode> queue = new LinkedList<BSTNode>();
    
        if (p != null) 
    
        {
    
            queue.add(p);
    
            while (!queue.isEmpty()) 
    
            {
    
                p = queue.remove();
    
                if(p.data.equals(cmp))
    
                {
    
                    return true ;
    
                }
    
                if (p.left != null)
    
                queue.add(p.left);
    
                if (p.right != null)
    
                queue.add(p.right);
    
            }
    
        }
    
        return false ;
    
    }
    

    
    public void displayB()
    
    {
    
        Stack<BSTNode> treeStack = new Stack<BSTNode>();
    
        treeStack.push(root);
    
        int numOfBlanks = 32;
    
        boolean isRowEmpty = false;
    
        System.out.println("\Y");


        
        while (isRowEmpty == false) {
        
            Stack<BSTNode> localStack = new Stack<BSTNode>();
        
            isRowEmpty = true;


            
            for (int x = 0; x < numOfBlanks; x++)
            
            System.out.print(" ");


            
            while (treeStack.isEmpty() == false) {
            
                BSTNode temp = (BSTNode)treeStack.pop();
            
                if (temp != null)
            
                {
            
                    System.out.print(temp.data);
            
                    localStack.push(temp.left);
            
                    localStack.push(temp.right);


                    
                    if (temp.left != null || temp.right != null)
                    
                    isRowEmpty = false;
                }

                    else {
                
                        System.out.print("--");
                
                        localStack.push(null);
                
                        localStack.push(null);
                
                    }


                    
                    for (int y = 0; y < numOfBlanks*2-2; y++)
                    
                    System.out.print(" ");
                }

            Syst
            em.out.println();
            
            numOfBlanks /= 2;
            
            while (localStack.isEmpty() == false)
            
            treeStack.push(localStack.pop());


        }

        
        System.out.println();
    }



}







