package myPackage;
import java.util.Vector;



public class WordFunc 

{

	Vector<String> words = new Vector<String>();

	Vector freq = new Vector();

	void add_word(String w)

	{

		words.add(w) ;

		freq.add(1) ;

	}

	int get_freq(String s)

	{

		int s1 =  (Integer) freq.elementAt(words.indexOf(s)) ;

		return s1 ;

	}

	void display()
	{

		System.out.println(words);

		System.out.println(freq);

	}

	void inc_freq(String s)

	{

		int i = words.indexOf(s) ;

		int j =  (Integer) freq.elementAt(i) ;

		j++ ;

		freq.set(i,j) ;

	}

	boolean search(String s)

	{

		for(int i=0 ; i<words.size() ; i++)

		{

			if(s.equals(words.elementAt(i)))

			{

				return false ;

			}
		}

		return true ;

	}

	
	

}







